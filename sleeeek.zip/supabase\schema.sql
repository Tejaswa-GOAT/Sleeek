-- Drop existing policies if they exist (safe re-run)
drop policy if exists "rooms_select"  on public.rooms;
drop policy if exists "rooms_insert"  on public.rooms;
drop policy if exists "rooms_update"  on public.rooms;
drop policy if exists "rooms_delete"  on public.rooms;
drop policy if exists "members_select" on public.room_members;
drop policy if exists "members_insert" on public.room_members;
drop policy if exists "members_delete" on public.room_members;

-- Rooms
create table if not exists public.rooms (
  id         uuid        default gen_random_uuid() primary key,
  code       text        unique not null,
  name       text        not null,
  created_by uuid        references auth.users(id) on delete cascade not null,
  created_at timestamptz default now() not null
);

-- Room members
create table if not exists public.room_members (
  id        uuid        default gen_random_uuid() primary key,
  room_id   uuid        references public.rooms(id) on delete cascade not null,
  user_id   uuid        references auth.users(id) on delete cascade not null,
  joined_at timestamptz default now() not null,
  unique(room_id, user_id)
);

-- Enable RLS
alter table public.rooms        enable row level security;
alter table public.room_members enable row level security;

-- Recreate policies
create policy "rooms_select"  on public.rooms for select to authenticated using (true);
create policy "rooms_insert"  on public.rooms for insert to authenticated with check (auth.uid() = created_by);
create policy "rooms_update"  on public.rooms for update to authenticated using (auth.uid() = created_by);
create policy "rooms_delete"  on public.rooms for delete to authenticated using (auth.uid() = created_by);

create policy "members_select" on public.room_members for select to authenticated using (true);
create policy "members_insert" on public.room_members for insert to authenticated with check (auth.uid() = user_id);
create policy "members_delete" on public.room_members for delete to authenticated using (auth.uid() = user_id);
