﻿import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        bg: "#0a0a0a",
        surface: "#121212",
        accent: {
          DEFAULT: "#5227FF",
          light: "#7F5AF0",
          dark: "#3B1FAB",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 30px rgba(82,39,255,0.35), 0 0 60px rgba(82,39,255,0.12)",
        "glow-sm": "0 0 15px rgba(82,39,255,0.25)",
        "glow-lg": "0 0 50px rgba(82,39,255,0.45), 0 0 100px rgba(82,39,255,0.18)",
      },
      keyframes: {
        "glow-pulse": {
          "0%,100%": { boxShadow: "0 0 20px rgba(82,39,255,0.3)" },
          "50%": { boxShadow: "0 0 45px rgba(82,39,255,0.65)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% center" },
          "100%": { backgroundPosition: "200% center" },
        },
      },
      animation: {
        "glow-pulse": "glow-pulse 3s ease-in-out infinite",
        shimmer: "shimmer 3s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;
