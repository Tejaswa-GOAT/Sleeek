﻿import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Metadata } from "next";
import { DashboardShell } from "@/components/DashboardShell";

export const metadata: Metadata = {
  title: "Dashboard Ã¢â‚¬â€ Sleeeek",
};

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // Fetch rooms the user is a member of
  const { data: memberships } = await supabase
    .from("room_members")
    .select("room_id, rooms(id, code, name, created_by, created_at)")
    .eq("user_id", user.id)
    .order("joined_at", { ascending: false });

  const rooms = (memberships ?? []).map((m: any) => m.rooms).filter(Boolean);

  return <DashboardShell user={user} rooms={rooms} />;
}
