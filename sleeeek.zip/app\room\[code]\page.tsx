import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import { Metadata } from "next";
import { RoomShell } from "@/components/RoomShell";

interface Props { params: Promise<{ code: string }>; }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { code } = await params;
  return { title: "Room " + code + " -- Sleeeek" };
}

export default async function RoomPage({ params }: Props) {
  const { code } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/room/" + code);

  const { data: room } = await supabase
    .from("rooms").select("*").eq("code", code.toUpperCase()).maybeSingle();
  if (!room) notFound();

  await supabase.from("room_members").upsert(
    { room_id: room.id, user_id: user.id },
    { onConflict: "room_id,user_id" }
  );

  const { data: members } = await supabase
    .from("room_members").select("user_id, joined_at")
    .eq("room_id", room.id).order("joined_at");

  return <RoomShell room={room} user={user} members={members ?? []} />;
}