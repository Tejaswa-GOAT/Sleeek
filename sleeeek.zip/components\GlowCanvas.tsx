﻿"use client";

import { useEffect, useRef } from "react";

interface Beam {
  phase: number;
  speed: number;
  halfWidth: number;
  opacity: number;
  r1: number; g1: number; b1: number;
  r2: number; g2: number; b2: number;
}

const BEAMS: Beam[] = [
  { phase: 0.0,  speed: 0.00014, halfWidth: 160, opacity: 0.20, r1:82,  g1:39,  b1:255, r2:127, g2:90, b2:240 },
  { phase: 2.2,  speed: 0.00009, halfWidth: 220, opacity: 0.13, r1:127, g1:90,  b1:240, r2:196, g2:181,b2:253 },
  { phase: 4.0,  speed: 0.00017, halfWidth: 120, opacity: 0.16, r1:59,  g1:31,  b1:171, r2:82,  g2:39, b2:255 },
  { phase: 1.1,  speed: 0.00007, halfWidth: 300, opacity: 0.08, r1:82,  g1:39,  b1:255, r2:255, g2:255,b2:255 },
  { phase: 3.5,  speed: 0.00012, halfWidth: 180, opacity: 0.11, r1:127, g1:90,  b1:240, r2:82,  g2:39, b2:255 },
];

export function GlowCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    const start = performance.now();

    function resize() {
      canvas!.width = window.innerWidth;
      canvas!.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    function hex2(v: number) {
      return Math.round(Math.min(v, 1) * 255).toString(16).padStart(2, "0");
    }

    function draw(now: number) {
      const t = now - start;
      const w = canvas!.width;
      const h = canvas!.height;
      const diag = Math.hypot(w, h);

      ctx!.clearRect(0, 0, w, h);
      ctx!.save();
      // Rotate canvas 45Ã‚Â° around its center for diagonal beams
      ctx!.translate(w / 2, h / 2);
      ctx!.rotate(Math.PI / 4);

      for (const b of BEAMS) {
        // Position oscillates across the full diagonal + padding
        const pos = ((Math.sin(t * b.speed + b.phase) + 1) / 2) * (diag + b.halfWidth * 2) - diag / 2 - b.halfWidth;

        const grad = ctx!.createLinearGradient(pos, 0, pos + b.halfWidth * 2, 0);
        const c1 = `rgba(${b.r1},${b.g1},${b.b1},`;
        const c2 = `rgba(${b.r2},${b.g2},${b.b2},`;
        grad.addColorStop(0,   `${c1}0)`);
        grad.addColorStop(0.25,`${c1}${b.opacity.toFixed(3)})`);
        grad.addColorStop(0.5, `${c2}${(b.opacity * 1.6).toFixed(3)})`);
        grad.addColorStop(0.75,`${c1}${b.opacity.toFixed(3)})`);
        grad.addColorStop(1,   `${c1}0)`);

        ctx!.fillStyle = grad;
        ctx!.fillRect(pos, -diag, b.halfWidth * 2, diag * 2);
      }
      ctx!.restore();

      animId = requestAnimationFrame(draw);
    }

    animId = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="fixed inset-0 w-full h-full pointer-events-none select-none"
      style={{ zIndex: 0 }}
    />
  );
}
