﻿import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sleeeek Ã¢â‚¬â€ Watch Together",
  description:
    "Host private watch parties with friends. Sync videos, share screens, and vibe together in real time.",
  keywords: ["watch party", "screen share", "video sync", "watch together"],
  openGraph: {
    title: "Sleeeek Ã¢â‚¬â€ Watch Together",
    description: "Private watch parties for you and your crew.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
      </head>
      <body className="bg-[#0a0a0a] text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
