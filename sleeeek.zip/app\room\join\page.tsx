﻿import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Metadata } from "next";
import { JoinRoomForm } from "@/components/JoinRoomForm";
import { GlowCanvas } from "@/components/GlowCanvas";

export const metadata: Metadata = { title: "Join Room Ã¢â‚¬â€ Sleeeek" };

export default async function JoinRoomPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/room/join");
  return (
    <main className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
      <GlowCanvas />
      <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 1, background: "radial-gradient(ellipse 70% 60% at 50% 50%, transparent 30%, #0a0a0a 100%)" }} />
      <JoinRoomForm />
    </main>
  );
}
