﻿"use server";

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

function generateCode(): string {
  // Unambiguous uppercase alphanumeric chars (no 0/O, 1/I/L)
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 6 }, () =>
    chars[Math.floor(Math.random() * chars.length)]
  ).join("");
}

export async function createRoom(
  prevState: { error?: string } | null,
  formData: FormData
) {
  const name = (formData.get("name") as string)?.trim();
  if (!name || name.length < 2) {
    return { error: "Room name must be at least 2 characters." };
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // Generate a unique code (retry on collision)
  let code = generateCode();
  let attempts = 0;
  while (attempts < 5) {
    const { data: existing } = await supabase
      .from("rooms")
      .select("id")
      .eq("code", code)
      .maybeSingle();
    if (!existing) break;
    code = generateCode();
    attempts++;
  }

  const { data: room, error } = await supabase
    .from("rooms")
    .insert({ name, code, created_by: user.id })
    .select()
    .single();

  if (error) return { error: error.message };

  await supabase.from("room_members").insert({
    room_id: room.id,
    user_id: user.id,
  });

  redirect(`/room/${room.code}`);
}

export async function joinRoom(
  prevState: { error?: string } | null,
  formData: FormData
) {
  const code = (formData.get("code") as string)?.toUpperCase().trim();
  if (!code || code.length < 4) {
    return { error: "Please enter a valid room code." };
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: room, error } = await supabase
    .from("rooms")
    .select()
    .eq("code", code)
    .maybeSingle();

  if (error || !room) {
    return { error: "Room not found. Double-check your code." };
  }

  await supabase.from("room_members").upsert(
    { room_id: room.id, user_id: user.id },
    { onConflict: "room_id,user_id" }
  );

  redirect(`/room/${room.code}`);
}
