﻿import { Metadata } from "next";
import { LoginForm } from "@/components/LoginForm";
import { GlowCanvas } from "@/components/GlowCanvas";

export const metadata: Metadata = {
  title: "Sign In Ã¢â‚¬â€ Sleeeek",
  description: "Sign in to Sleeeek with a magic link Ã¢â‚¬â€ no password required.",
};

export default function LoginPage() {
  return (
    <main className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
      <GlowCanvas />
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          zIndex: 1,
          background:
            "radial-gradient(ellipse 70% 60% at 50% 50%, transparent 30%, #0a0a0a 100%)",
        }}
      />
      <LoginForm />
    </main>
  );
}
