﻿import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Metadata } from "next";
import { CreateRoomForm } from "@/components/CreateRoomForm";
import { GlowCanvas } from "@/components/GlowCanvas";

export const metadata: Metadata = { title: "Create Room Ã¢â‚¬â€ Sleeeek" };

export default async function CreateRoomPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/room/create");
  return (
    <main className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
      <GlowCanvas />
      <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 1, background: "radial-gradient(ellipse 70% 60% at 50% 50%, transparent 30%, #0a0a0a 100%)" }} />
      <CreateRoomForm />
    </main>
  );
}
