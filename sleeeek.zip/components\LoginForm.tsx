﻿"use client";

import { useActionState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { signInWithMagicLink } from "@/app/actions/auth";
import { GlassCard } from "./GlassCard";

const spring = { type: "spring" as const, stiffness: 260, damping: 22 };

export function LoginForm() {
  const searchParams = useSearchParams();
  const mode = searchParams.get("mode");
  const next = mode === "create" ? "/room/create" : mode === "join" ? "/room/join" : "/dashboard";
  const authError = searchParams.get("error");

  const [state, action, isPending] = useActionState(signInWithMagicLink, null);

  return (
    <GlassCard
      className="relative w-full max-w-md p-10 flex flex-col gap-8"
      style={{ zIndex: 2 }}
      initial={{ opacity: 0, y: 36, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ ...spring, delay: 0.05 }}
    >
      {/* Logo */}
      <div className="text-center">
        <motion.h1
          className="text-4xl font-extrabold gradient-text"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15 }}
        >
          Sleeeek
        </motion.h1>
        <motion.p
          className="mt-2 text-sm text-white/45"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {mode === "create"
            ? "Sign in to create your watch room"
            : mode === "join"
            ? "Sign in to join a room"
            : "Welcome back"}
        </motion.p>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {state?.success ? (
          <motion.div
            key="success"
            className="flex flex-col items-center gap-4 text-center py-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={spring}
          >
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
              style={{ background: "rgba(82,39,255,0.2)", border: "1px solid rgba(82,39,255,0.4)" }}
            >
              Ã¢Å“â€°Ã¯Â¸Â
            </div>
            <div>
              <p className="font-semibold text-white">Check your inbox</p>
              <p className="text-sm text-white/50 mt-1">
                We sent a magic link to{" "}
                <span className="text-accent-light font-medium">{state.email}</span>.
              </p>
            </div>
            <p className="text-xs text-white/30">
              Click the link in the email to sign in. You can close this tab.
            </p>
          </motion.div>
        ) : (
          <motion.form
            key="form"
            action={action}
            className="flex flex-col gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <input type="hidden" name="next" value={next} />

            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-sm text-white/60 font-medium">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                placeholder="you@example.com"
                className="input"
                autoFocus
              />
            </div>

            <AnimatePresence>
              {(state?.error || authError) && (
                <motion.p
                  className="error-text"
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                >
                  {state?.error || "Authentication failed. Please try again."}
                </motion.p>
              )}
            </AnimatePresence>

            <motion.button
              type="submit"
              disabled={isPending}
              className="btn-primary mt-2"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              transition={spring}
            >
              {isPending ? (
                <span className="flex items-center gap-2">
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Sending linkÃ¢â‚¬Â¦
                </span>
              ) : (
                "Ã¢Å“Â¦ Send Magic Link"
              )}
            </motion.button>

            <p className="text-xs text-center text-white/30">
              No password needed Ã¢â‚¬â€ we&apos;ll email you a one-click sign-in link.
            </p>
          </motion.form>
        )}
      </AnimatePresence>
    </GlassCard>
  );
}
