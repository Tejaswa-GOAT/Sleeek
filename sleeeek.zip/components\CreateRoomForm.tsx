﻿"use client";

import { useActionState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { createRoom } from "@/app/actions/room";
import { GlassCard } from "./GlassCard";

const spring = { type: "spring" as const, stiffness: 260, damping: 22 };

export function CreateRoomForm() {
  const [state, action, isPending] = useActionState(createRoom, null);

  return (
    <GlassCard
      className="relative w-full max-w-md p-10 flex flex-col gap-7"
      style={{ zIndex: 2 }}
      initial={{ opacity: 0, y: 36, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ ...spring, delay: 0.05 }}
    >
      <div>
        <Link href="/dashboard" className="text-xs text-white/35 hover:text-white/60 transition-colors">Ã¢â€ Â Back</Link>
        <h1 className="text-2xl font-bold mt-3 text-white">Create a room</h1>
        <p className="text-sm text-white/40 mt-1">Give your watch party a name. A unique code will be generated.</p>
      </div>

      <form action={action} className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <label htmlFor="name" className="text-sm font-medium text-white/60">Room name</label>
          <input id="name" name="name" type="text" className="input" placeholder="Movie Night Ã°Å¸Å½Â¬" required autoFocus />
        </div>

        <AnimatePresence>
          {state?.error && (
            <motion.p className="error-text" initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {state.error}
            </motion.p>
          )}
        </AnimatePresence>

        <motion.button type="submit" disabled={isPending} className="btn-primary mt-2" whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} transition={spring}>
          {isPending ? (
            <span className="flex items-center gap-2">
              <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              CreatingÃ¢â‚¬Â¦
            </span>
          ) : "Ã¢Å“Â¦ Create Room"}
        </motion.button>
      </form>
    </GlassCard>
  );
}
