﻿"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { GlowCanvas } from "./GlowCanvas";
import { GlassCard } from "./GlassCard";

const spring = { type: "spring" as const, stiffness: 260, damping: 22 };

export function LandingHero() {
  return (
    <main className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden px-4">
      {/* Animated diagonal glow background */}
      <GlowCanvas />

      {/* Radial vignette so glass card "floats" */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          zIndex: 1,
          background:
            "radial-gradient(ellipse 80% 70% at 50% 50%, transparent 40%, #0a0a0a 100%)",
        }}
      />

      {/* Hero card */}
      <GlassCard
        className="relative w-full max-w-lg p-10 text-center flex flex-col items-center gap-8"
        style={{ zIndex: 2 }}
        initial={{ opacity: 0, y: 40, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ ...spring, delay: 0.1 }}
      >
        {/* Logo pill */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ ...spring, delay: 0.2 }}
          className="px-4 py-1.5 rounded-full text-xs font-semibold tracking-widest uppercase"
          style={{
            background: "rgba(82,39,255,0.18)",
            border: "1px solid rgba(82,39,255,0.35)",
            color: "#a78bfa",
          }}
        >
          Private Watch Parties
        </motion.div>

        {/* Wordmark */}
        <motion.h1
          className="text-7xl font-extrabold leading-none tracking-tight gradient-text"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...spring, delay: 0.25 }}
        >
          Sleeeek
        </motion.h1>

        <motion.p
          className="text-base text-white/55 max-w-xs leading-relaxed"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...spring, delay: 0.35 }}
        >
          Sync any video, share your screen, and vibe with friends Ã¢â‚¬â€ all in one
          glowing room.
        </motion.p>

        {/* Feature pills */}
        <motion.div
          className="flex flex-wrap justify-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.45 }}
        >
          {["Ã°Å¸Å½Â¬ Video Sync", "Ã°Å¸â€“Â¥ Screen Share", "Ã°Å¸Å½Âµ Soundboard", "Ã°Å¸â€˜Â¥ Avatars"].map(
            (f) => (
              <span
                key={f}
                className="px-3 py-1 rounded-full text-xs text-white/60"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                {f}
              </span>
            )
          )}
        </motion.div>

        {/* CTA buttons */}
        <motion.div
          className="flex flex-col sm:flex-row gap-3 w-full"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...spring, delay: 0.5 }}
        >
          <motion.div className="flex-1" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} transition={spring}>
            <Link href="/login?mode=create" className="btn-primary w-full text-sm">
              Ã¢Å“Â¦ Create Room
            </Link>
          </motion.div>
          <motion.div className="flex-1" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} transition={spring}>
            <Link href="/login?mode=join" className="btn-ghost w-full text-sm">
              Join Room Ã¢â€ â€™
            </Link>
          </motion.div>
        </motion.div>

        <motion.p
          className="text-xs text-white/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          No account? Sign in instantly via magic link Ã¢â‚¬â€ no password needed.
        </motion.p>
      </GlassCard>

      {/* Bottom gradient fade */}
      <div
        className="fixed bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{
          zIndex: 1,
          background: "linear-gradient(to top, #0a0a0a, transparent)",
        }}
      />
    </main>
  );
}
