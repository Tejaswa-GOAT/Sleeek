﻿"use client";
import { motion, HTMLMotionProps } from "framer-motion";
import { forwardRef } from "react";

interface GlassCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  className?: string;
  glowOnHover?: boolean;
}

export const GlassCard = forwardRef<HTMLDivElement, GlassCardProps>(
  ({ children, className = "", glowOnHover = true, ...rest }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={`glass ${className}`}
        whileHover={glowOnHover ? { scale: 1.005 } : undefined}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        {...rest}
      >
        {children}
      </motion.div>
    );
  }
);
GlassCard.displayName = "GlassCard";
