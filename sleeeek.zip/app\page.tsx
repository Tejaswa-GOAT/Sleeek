﻿import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { LandingHero } from "@/components/LandingHero";

export default async function HomePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // If already signed in, send to room dashboard
  if (user) redirect("/dashboard");

  return <LandingHero />;
}
