﻿"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { GlowCanvas } from "./GlowCanvas";
import { GlassCard } from "./GlassCard";
import { signOut } from "@/app/actions/auth";
import type { User } from "@supabase/supabase-js";
import type { Room } from "@/lib/types";

const spring = { type: "spring" as const, stiffness: 260, damping: 22 };
const containerVariants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07 } },
};
const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: spring },
};

interface Props {
  user: User;
  rooms: Room[];
}

function initials(email: string) {
  return email.slice(0, 2).toUpperCase();
}

export function DashboardShell({ user, rooms }: Props) {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <GlowCanvas />
      <div
        className="fixed inset-0 pointer-events-none"
        style={{ zIndex: 1, background: "radial-gradient(ellipse 90% 80% at 50% 20%, transparent 40%, #0a0a0a 100%)" }}
      />

      {/* Nav */}
      <motion.nav
        className="relative flex items-center justify-between px-6 py-4"
        style={{ zIndex: 10 }}
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={spring}
      >
        <span className="text-2xl font-extrabold gradient-text">Sleeeek</span>
        <div className="flex items-center gap-3">
          <div className="avatar text-sm">{initials(user.email ?? "?")}</div>
          <form action={signOut}>
            <motion.button
              type="submit"
              className="btn-ghost text-sm px-4 py-2"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              transition={spring}
            >
              Sign out
            </motion.button>
          </form>
        </div>
      </motion.nav>

      {/* Body */}
      <main className="relative px-6 pb-20 max-w-3xl mx-auto" style={{ zIndex: 2 }}>
        <motion.div
          className="flex flex-col sm:flex-row gap-3 mb-10 mt-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...spring, delay: 0.1 }}
        >
          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} transition={spring}>
            <Link href="/room/create" className="btn-primary text-sm">Ã¢Å“Â¦ Create Room</Link>
          </motion.div>
          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} transition={spring}>
            <Link href="/room/join" className="btn-ghost text-sm">Join Room Ã¢â€ â€™</Link>
          </motion.div>
        </motion.div>

        <motion.h2
          className="text-sm font-semibold uppercase tracking-widest text-white/40 mb-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          Your Rooms
        </motion.h2>

        {rooms.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ ...spring, delay: 0.2 }}
          >
            <GlassCard className="p-12 text-center flex flex-col items-center gap-4" glowOnHover={false}>
              <div className="text-5xl">Ã°Å¸Å½Â¬</div>
              <p className="text-white/40 text-sm">No rooms yet. Create one or join with a code.</p>
            </GlassCard>
          </motion.div>
        ) : (
          <motion.div
            className="flex flex-col gap-3"
            variants={containerVariants}
            initial="hidden"
            animate="show"
          >
            {rooms.map((room) => (
              <motion.div key={room.id} variants={itemVariants}>
                <GlassCard className="px-5 py-4 flex items-center justify-between gap-4">
                  <div>
                    <p className="font-semibold text-white">{room.name}</p>
                    <p className="text-xs text-white/35 mt-0.5 font-mono tracking-wider">{room.code}</p>
                  </div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} transition={spring}>
                    <Link href={`/room/${room.code}`} className="btn-primary text-xs px-4 py-2.5">
                      Enter Ã¢â€ â€™
                    </Link>
                  </motion.div>
                </GlassCard>
              </motion.div>
            ))}
          </motion.div>
        )}
      </main>
    </div>
  );
}
