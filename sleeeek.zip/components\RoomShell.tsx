﻿"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { GlowCanvas } from "./GlowCanvas";
import { GlassCard } from "./GlassCard";
import { signOut } from "@/app/actions/auth";
import type { User } from "@supabase/supabase-js";
import type { Room } from "@/lib/types";

const spring = { type: "spring" as const, stiffness: 260, damping: 22 };

function initials(userId: string) {
  return userId.slice(0, 2).toUpperCase();
}

interface Props {
  room: Room;
  user: User;
  members: { user_id: string; joined_at: string }[];
}

export function RoomShell({ room, user, members }: Props) {
  const [copied, setCopied] = useState(false);

  function copyCode() {
    navigator.clipboard.writeText(room.code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <div className="relative min-h-screen overflow-hidden flex flex-col">
      <GlowCanvas />
      <div
        className="fixed inset-0 pointer-events-none"
        style={{ zIndex: 1, background: "radial-gradient(ellipse 100% 60% at 50% 0%, rgba(82,39,255,0.06) 0%, transparent 60%)" }}
      />

      {/* Top Nav */}
      <motion.header
        className="relative flex items-center justify-between px-5 py-3 border-b"
        style={{ zIndex: 10, borderColor: "rgba(255,255,255,0.07)", background: "rgba(10,10,10,0.7)", backdropFilter: "blur(20px)" }}
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={spring}
      >
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="text-xs text-white/35 hover:text-white/65 transition-colors">Ã¢â€ Â Rooms</Link>
          <div className="h-4 w-px bg-white/10" />
          <span className="font-semibold text-white text-sm">{room.name}</span>
        </div>

        {/* Code badge + copy */}
        <div className="flex items-center gap-3">
          <motion.button
            onClick={copyCode}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono tracking-widest transition-colors"
            style={{ background: "rgba(82,39,255,0.12)", border: "1px solid rgba(82,39,255,0.3)", color: "#a78bfa" }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={spring}
          >
            {room.code}
            <AnimatePresence mode="wait">
              {copied ? (
                <motion.span key="check" initial={{ opacity: 0, scale: 0.7 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>Ã¢Å“â€œ</motion.span>
              ) : (
                <motion.span key="copy" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="opacity-60">Ã¢Å½Ëœ</motion.span>
              )}
            </AnimatePresence>
          </motion.button>

          <div className="avatar w-8 h-8 text-xs">{initials(user.id)}</div>
          <form action={signOut}>
            <motion.button type="submit" className="btn-ghost text-xs px-3 py-2" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }} transition={spring}>
              Sign out
            </motion.button>
          </form>
        </div>
      </motion.header>

      {/* Main */}
      <div className="relative flex flex-1 gap-4 p-4 overflow-hidden" style={{ zIndex: 2 }}>
        {/* Video stage placeholder */}
        <motion.div
          className="flex-1 flex flex-col items-center justify-center min-h-[400px] rounded-2xl"
          style={{ background: "rgba(255,255,255,0.025)", border: "1px dashed rgba(255,255,255,0.1)" }}
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ ...spring, delay: 0.1 }}
        >
          <div className="flex flex-col items-center gap-4 text-center px-8 max-w-sm">
            <motion.div
              className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl"
              style={{ background: "rgba(82,39,255,0.12)", border: "1px solid rgba(82,39,255,0.25)" }}
              animate={{ boxShadow: ["0 0 20px rgba(82,39,255,0.2)", "0 0 40px rgba(82,39,255,0.4)", "0 0 20px rgba(82,39,255,0.2)"] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              Ã°Å¸Å½Â¬
            </motion.div>
            <div>
              <p className="font-semibold text-white text-lg">Room is ready</p>
              <p className="text-sm text-white/35 mt-1.5 leading-relaxed">
                Video sync and screen share coming in Phase 2.
                <br />Invite friends with code{" "}
                <span
                  className="font-mono text-accent-light cursor-pointer"
                  onClick={copyCode}
                >
                  {room.code}
                </span>.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Members sidebar */}
        <motion.aside
          className="w-64 hidden sm:flex flex-col gap-3"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ ...spring, delay: 0.15 }}
        >
          <GlassCard className="p-4 flex flex-col gap-3 flex-1" glowOnHover={false}>
            <p className="text-xs font-semibold uppercase tracking-widest text-white/35">
              Members Ã‚Â· {members.length}
            </p>
            <div className="flex flex-col gap-2">
              {members.map((m, i) => (
                <motion.div
                  key={m.user_id}
                  className="flex items-center gap-3"
                  initial={{ opacity: 0, x: 12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ ...spring, delay: 0.2 + i * 0.05 }}
                >
                  <div
                    className="avatar"
                    style={m.user_id === user.id ? { border: "1.5px solid #7f5af0", boxShadow: "0 0 10px rgba(82,39,255,0.3)" } : {}}
                  >
                    {initials(m.user_id)}
                  </div>
                  <div className="flex flex-col min-w-0">
                    <p className="text-xs font-medium text-white/80 truncate">
                      {m.user_id === user.id ? "You" : `Member ${m.user_id.slice(0, 4)}`}
                    </p>
                    <p className="text-[10px] text-white/30 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block" />
                      Watching
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </motion.aside>
      </div>
    </div>
  );
}
